package com.raythedj.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

private val BG = Color(0xFF080B13)
private val PANEL = Color(0xFF141B2A)
private val CYAN = Color(0xFF00D9FF)
private val PURPLE = Color(0xFF9B6DFF)
private val MUTED = Color(0xFF9AA8BD)

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  setContent { RayDjApp() }
 }
}

@Composable
fun RayDjApp() {
 val context = LocalContext.current
 val players = remember { List(4) { ExoPlayer.Builder(context).build().apply { playWhenReady = false } } }
 DisposableEffect(Unit) { onDispose { players.forEach { it.release() } } }
 var selected by remember { mutableIntStateOf(0) }
 var crossfader by remember { mutableFloatStateOf(0.5f) }
 val gains = remember { mutableStateListOf(1f,1f,1f,1f) }
 val speeds = remember { mutableStateListOf(1f,1f,1f,1f) }
 val loaded = remember { mutableStateListOf(false,false,false,false) }
 var status by remember { mutableStateOf("LOAD TRACKS TO BEGIN") }
 val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
  if (uri != null) {
   try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
   players[selected].setMediaItem(MediaItem.fromUri(uri)); players[selected].prepare()
   loaded[selected] = true; status = "DECK ${selected+1} READY"
  }
 }
 LaunchedEffect(crossfader, gains.toList()) {
  players.forEachIndexed { i,p -> p.volume = (gains[i] * if (i%2==0) 1f-crossfader else crossfader).coerceIn(0f,1f) }
 }
 MaterialTheme(colorScheme = darkColorScheme(background=BG, surface=PANEL, primary=CYAN, secondary=PURPLE)) {
  Column(Modifier.fillMaxSize().background(BG).padding(9.dp), verticalArrangement=Arrangement.spacedBy(7.dp)) {
   Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween) {
    Column {
     Text("RAY THE DJ 🚀", color=Color.White, fontSize=23.sp, fontWeight=FontWeight.Black)
     Text("PROFESSIONAL MOBILE MIX STUDIO • BUILD 0.1", color=CYAN, fontSize=9.sp, fontWeight=FontWeight.Bold)
    }
    Text(status, color=MUTED, fontSize=10.sp)
   }
   LazyVerticalGrid(columns=GridCells.Fixed(2), modifier=Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(7.dp), horizontalArrangement=Arrangement.spacedBy(7.dp)) {
    itemsIndexed(players) { i,p ->
     DeckCard(i,p,loaded[i],gains[i],speeds[i],
      onLoad={ selected=i; picker.launch(arrayOf("audio/*","video/*")) },
      onGain={ gains[i]=it },
      onSpeed={ speeds[i]=it; p.playbackParameters=PlaybackParameters(it) },
      onStatus={ status=it })
    }
   }
   Row(Modifier.fillMaxWidth().background(PANEL,RoundedCornerShape(12.dp)).padding(horizontal=12.dp, vertical=3.dp), verticalAlignment=Alignment.CenterVertically) {
    Text("CROSSFADER", color=CYAN, fontSize=10.sp, fontWeight=FontWeight.Bold)
    Spacer(Modifier.width(8.dp)); Text("A",color=MUTED,fontSize=10.sp)
    Slider(crossfader,{crossfader=it},Modifier.weight(1f),colors=SliderDefaults.colors(thumbColor=CYAN,activeTrackColor=CYAN))
    Text("B",color=MUTED,fontSize=10.sp)
   }
   Text("Load audio/video files into each deck. Starter features: independent playback, gain, speed and crossfader.", color=MUTED,fontSize=9.sp)
  }
 }
}

@Composable
private fun DeckCard(index:Int, player:ExoPlayer, loaded:Boolean, gain:Float, speed:Float,
 onLoad:()->Unit, onGain:(Float)->Unit, onSpeed:(Float)->Unit, onStatus:(String)->Unit) {
 var playing by remember { mutableStateOf(false) }
 var position by remember { mutableLongStateOf(0L) }
 var duration by remember { mutableLongStateOf(0L) }
 LaunchedEffect(player,loaded) {
  while(true) { playing=player.isPlaying; position=player.currentPosition.coerceAtLeast(0); duration=player.duration.takeIf{it>0}?:0; delay(400) }
 }
 Card(colors=CardDefaults.cardColors(containerColor=PANEL), shape=RoundedCornerShape(12.dp), modifier=Modifier.fillMaxWidth()) {
  Column(Modifier.padding(8.dp), verticalArrangement=Arrangement.spacedBy(3.dp)) {
   Row(verticalAlignment=Alignment.CenterVertically) {
    Text("DECK ${index+1}",color=if(index%2==0) CYAN else PURPLE,fontWeight=FontWeight.Black,fontSize=14.sp)
    Spacer(Modifier.weight(1f)); Text(if(loaded)"READY" else "EMPTY",color=if(loaded) CYAN else MUTED,fontSize=9.sp)
   }
   Box(Modifier.fillMaxWidth().height(65.dp).background(Color.Black,RoundedCornerShape(7.dp))) {
    if(loaded) AndroidView(factory={ctx->PlayerView(ctx).apply{this.player=player;useController=false}},update={it.player=player},modifier=Modifier.fillMaxSize())
    else Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text("VIDEO / DECK PREVIEW",color=MUTED,fontSize=9.sp)}
   }
   Row(verticalAlignment=Alignment.CenterVertically) {
    Button(onClick=onLoad,contentPadding=PaddingValues(horizontal=9.dp,vertical=2.dp)){Text("LOAD",fontSize=9.sp)}
    Spacer(Modifier.width(5.dp))
    Button(onClick={if(player.isPlaying){player.pause();onStatus("DECK ${index+1} PAUSED")}else if(loaded){player.play();onStatus("DECK ${index+1} PLAYING")}},enabled=loaded,contentPadding=PaddingValues(horizontal=9.dp,vertical=2.dp)){Text(if(playing)"PAUSE" else "PLAY",fontSize=9.sp)}
    Spacer(Modifier.weight(1f))
    OutlinedButton(onClick={player.seekTo(0);player.pause();onStatus("DECK ${index+1} CUE")},enabled=loaded,contentPadding=PaddingValues(horizontal=7.dp,vertical=2.dp)){Text("CUE",fontSize=9.sp)}
   }
   Text("GAIN ${(gain*100).toInt()}%",color=MUTED,fontSize=9.sp)
   Slider(gain,onGain,valueRange=0f..1f,colors=SliderDefaults.colors(thumbColor=CYAN,activeTrackColor=CYAN))
   Text("PITCH / SPEED ${"%.2f".format(speed)}x",color=MUTED,fontSize=9.sp)
   Slider(speed,onSpeed,valueRange=0.8f..1.2f,colors=SliderDefaults.colors(thumbColor=PURPLE,activeTrackColor=PURPLE))
   if(loaded) {
    val progress=if(duration>0) position.toFloat()/duration else 0f
    Slider(progress,{if(duration>0)player.seekTo((duration*it).toLong())},colors=SliderDefaults.colors(thumbColor=CYAN,activeTrackColor=CYAN))
    Text("${clock(position)} / ${clock(duration)}",color=MUTED,fontSize=9.sp)
   }
  }
 }
}
private fun clock(ms:Long):String { val s=(ms/1000).coerceAtLeast(0); return "%02d:%02d".format(s/60,s%60) }
