# RAY THE DJ 🚀 — Android source project

Chronix-inspired original four-deck Android DJ foundation. Kotlin + Jetpack Compose + AndroidX Media3.

## Working in this starter (v0.1)
- Four independent media playback decks.
- Android file picker for audio and video on each deck.
- Video preview surface for supported video formats.
- Per-deck gain, playback-speed control, play/pause, cue-to-start and seek.
- Basic A/B crossfader: decks 1 & 3 fade on A; decks 2 & 4 fade on B.
- Landscape dark DJ console UI.

## Important: what is not implemented yet
This is a functional starter, not yet a club-grade professional DJ engine. It does not yet include BPM/key detection, beat grids, pitch-preserving time stretch, 3-band EQ, filters, scratch DSP, hot cues, beat loops, sampler, FX rack, mix recording/export, MIDI/HID controller mapping, or synchronized low-latency multi-deck audio. These are the next engineering milestones and require device testing. Video support depends on Android decoder and file-format support.

## Build an APK using only your Android phone (GitHub Actions)
1. Sign in to GitHub and create a repository named `ray-the-dj`.
2. Extract this ZIP on your phone.
3. Upload the project files and folders into the repository, preserving their paths (including `.github/workflows/android.yml`).
4. Open the repository's **Actions** tab. The included workflow builds a debug APK after upload.
5. Open the successful run and download the `ray-the-dj-debug-apk` artifact.
6. Extract the artifact ZIP and install `app-debug.apk`. If Android blocks it, allow installs from the app you used to download/open it.
7. Keep the repository as your source project. Future updates can be built by pushing changes.

## Build with Android Studio
Open this folder in Android Studio, sync Gradle, then select Build > Build Bundle(s) / APK(s) > Build APK(s). Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Next pro milestones
1. Low-latency audio engine, synchronized transport, BPM/key analysis and pitch-preserving time stretch.
2. 3-band EQ, filters, channel/master controls and headphone cue monitoring.
3. Beat grids, hot cues, quantized loops, slip mode, sampler and effects.
4. Dual video output, transitions, audio/video synchronization and external display.
5. Mix recording, encoding, export and background playback.
6. MIDI/HID controller mapping and hardware compatibility tests.

Application ID: `com.raythedj.app` | Minimum Android: 8.0 (API 26)
